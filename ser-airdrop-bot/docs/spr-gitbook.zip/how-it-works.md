# How It Works

## The Flywheel

```
You buy $SPR
      ↓
People trade $SPR
      ↓
Creator fees generated
      ↓
70% buys $PENGUIN automatically
      ↓
$PENGUIN lands in your wallet every 10 min
```

That's it. No staking. No claiming. No bullshit.

---

## The Split

Every $SPR trade generates creator fees:

| Split | Use |
|-------|-----|
| **70%** | Swapped to $PENGUIN → Airdropped to holders |
| **30%** | Keeps the flywheel running |

More volume = more $PENGUIN = bigger bags for everyone holding

---

## Minimum to Qualify

**100,000 $SPR**

Hold 100k+ and $PENGUIN airdrops hit your wallet automatically every 10 minutes.

---

## Sold? No Stress

The bot checks holdings before each airdrop.

Sold your $SPR? You'll miss that cycle and your share goes to holders.

But no permanent blacklist or any of that. Learn your lesson, buy back in, hold 100k+, and you're back in the next cycle stacking $PENGUIN again.

We've all papered before. Just get back in the game.
