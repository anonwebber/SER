# Table of contents

* [$SPR](README.md)
* [How It Works](how-it-works.md)
* [The Play](the-play.md)
* [FAQ](faq.md)
