# FAQ

## wen airdrop?
Every 10 minutes. Set a timer if you want but it just happens.

---

## how much $PENGUIN will I get?
Depends on volume and how much $SPR you hold. More $SPR = bigger share.

---

## do I need to claim?
No. It hits your wallet automatically.

---

## what's the minimum?
100,000 $SPR to qualify for airdrops.

---

## what if $PENGUIN goes to a billion?
Then your free airdrops are worth a lot more than you paid for $SPR. That's the point.

---

## why would I buy this instead of just $PENGUIN?
Because you'll paper $PENGUIN. You know it. We know it. $SPR forces you to accumulate without your shaky hands getting in the way.

---

## what if I sell and want back in?
No problem. Buy back 100k+ $SPR and you're eligible for the next airdrop cycle. No permanent bans. Just missed the cycles when you weren't holding.
